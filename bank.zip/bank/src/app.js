import express from "express";
import authRoutes from "./routes/auth.routes.js";
import branchRoutes from "./routes/branch.routes.js";

const app = express();

app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/branches", branchRoutes);

app.get("/", (req, res) => {
    res.status(200).json({
        success: true,
        message: "Core Banking API is running",
    });
});

export default app;