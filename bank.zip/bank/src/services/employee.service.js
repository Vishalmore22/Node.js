import bcrypt from "bcrypt";
import User from "../models/User.js";
import Branch from "../models/Branch.js";

export const createEmployeeService = async (employeeData) => {
    const {
        employeeId,
        firstName,
        lastName,
        email,
        phone,
        password,
        role,
        branch,
    } = employeeData;

    const existingEmployee = await User.findOne({
        employeeId
    });
    
    if (existingEmployee) {
        throw new Error("Employee ID already exists.");
    }
}
export const getAllEmployeesService = async () => {
    const employees = await User.find({
        role: {
            $in: ["branch_manager", "branch_employee"],
        },
    })
        .populate("branch", "branchCode branchName city")
        .select("-password")
        .sort({ createdAt: -1 });

    return employees;
};

export const getEmployeeByIdService = async (employeeId) => {
    const employee = await User.findById(employeeId)
        .populate("branch", "branchCode branchName city")
        .select("-password");

    if (!employee) {
        throw new Error("Employee not found.");
    }

    return employee;
};

export const updateEmployeeService = async (
    employeeId,
    updateData
) => {

    const employee = await User.findById(employeeId);

    if (!employee) {
        throw new Error("Employee not found.");
    }

    if (updateData.password) {
        updateData.password = await bcrypt.hash(
            updateData.password,
            10
        );
    }

    Object.assign(employee, updateData);

    await employee.save();

    return employee;
};

export const toggleEmployeeStatusService = async (
    employeeId
) => {

    const employee = await User.findById(employeeId);

    if (!employee) {
        throw new Error("Employee not found.");
    }

    employee.isActive = !employee.isActive;

    await employee.save();

    return employee;
};

export const getEmployeesByBranchService = async (
    branchId
) => {

    return await User.find({
        branch: branchId,
        role: {
            $in: [
                "branch_manager",
                "branch_employee",
            ],
        },
    })
        .populate("branch", "branchCode branchName")
        .select("-password");
};